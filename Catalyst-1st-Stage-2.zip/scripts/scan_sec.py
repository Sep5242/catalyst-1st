"""Catalyst 1st: SEC EDGAR filing discovery, not trade signals."""
import gzip
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
TICKERS = ["DVN", "OXY", "ORCL", "C", "UNH", "DELL", "INTC", "ASTS", "RDW", "SMR", "NNE"]
FORMS = {"8-K", "10-Q", "10-K", "6-K", "20-F"}
UA = os.environ.get("SEC_USER_AGENT", "").strip()
if not UA or "@" not in UA:
    raise SystemExit("Configure SEC_USER_AGENT as a GitHub Actions secret (descriptive name and contact email).")
HEADERS = {"User-Agent": UA, "Accept-Encoding": "gzip, deflate", "Accept": "application/json"}

def fetch(url):
    req = Request(url, headers=HEADERS)
    with urlopen(req, timeout=30) as response:
        raw = response.read()
        if response.headers.get("Content-Encoding", "").lower() == "gzip":
            raw = gzip.decompress(raw)
    return json.loads(raw)

def main():
    mapping = fetch("https://www.sec.gov/files/company_tickers.json")
    companies = {row["ticker"].upper(): row for row in mapping.values()}
    items, errors = [], []
    for ticker in TICKERS:
        row = companies.get(ticker)
        if not row:
            errors.append(f"{ticker}: no SEC CIK mapping")
            continue
        cik = int(row["cik_str"])
        try:
            filing = fetch(f"https://data.sec.gov/submissions/CIK{cik:010d}.json")
            recent = filing["filings"]["recent"]
            for i, form in enumerate(recent["form"]):
                if form not in FORMS:
                    continue
                accession = recent["accessionNumber"][i]
                document = recent["primaryDocument"][i]
                items.append({
                    "ticker": ticker,
                    "company": row["title"],
                    "form": form,
                    "filed": recent["filingDate"][i],
                    "url": f"https://www.sec.gov/Archives/edgar/data/{cik}/{accession.replace('-', '')}/{document}"
                })
                if sum(item["ticker"] == ticker for item in items) >= 5:
                    break
        except Exception as exc:
            errors.append(f"{ticker}: {type(exc).__name__}: {exc}")
        time.sleep(0.3)
    items.sort(key=lambda item: item["filed"], reverse=True)
    output = {"generated_at": datetime.now(timezone.utc).isoformat(), "source": "SEC EDGAR", "items": items, "errors": errors}
    target = ROOT / "data" / "sec-catalysts.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(f"Saved {len(items)} filings; {len(errors)} errors to {target}")
    if errors:
        print("\n".join(errors))

if __name__ == "__main__":
    main()

Generated SEC filing JSON will be written here after the first successful workflow run.

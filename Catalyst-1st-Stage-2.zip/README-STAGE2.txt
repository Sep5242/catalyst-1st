CATALYST 1ST — STAGE 2

Includes a scheduled GitHub Actions SEC EDGAR filing scanner.
Does not include or overwrite your existing index.html dashboard.

Upload files preserving these EXACT paths:
  .github/workflows/main.yml
  scripts/scan_sec.py

In GitHub repository Settings > Secrets and variables > Actions, create repository secret SEC_USER_AGENT with value like: Catalyst1st Research your-real-email@example.com
Use your own valid contact email; do not share it in chat.

Then Actions > Catalyst 1st SEC Scanner > Run workflow.
A successful run commits data/sec-catalysts.json.

The dashboard will NOT show the filings automatically until its HTML is updated to read the JSON.
Runs on weekdays around 13:15 UTC (8:15 EST / 9:15 EDT), subject to GitHub scheduling delays.

IMPORTANT: GitHub web upload does NOT unpack ZIP files. Unzip first in Files, and preserve folder paths when uploading (or use GitHub's web editor to create paths). Do not upload the ZIP itself to the repository expecting it to work.
